package org.example.controllers;

import org.example.entites.Species;
import org.example.services.SpeciesServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/species") // Tous les endpoints commenceront par /api/species
public class SpeciesController {

    @Autowired
    private SpeciesServices speciesServices;

    // ----------------- GET all species -----------------
    @GetMapping
    public Iterable<Species> getAllSpecies() {
        return speciesServices.getAllSpecies();
    }

    // ----------------- GET species by name -----------------
    @GetMapping("/{name}")
    public ResponseEntity<Species> getSpeciesByName(@PathVariable String name) {
        Optional<Species> speciesOpt = speciesServices.getSpeciesByName(name);
        return speciesOpt.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ----------------- POST create species -----------------
    @PostMapping
    public ResponseEntity<?> createSpecies(@RequestBody Species species) {
        try {
            Species created = speciesServices.createSpecies(species);
            return ResponseEntity.ok(created);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
