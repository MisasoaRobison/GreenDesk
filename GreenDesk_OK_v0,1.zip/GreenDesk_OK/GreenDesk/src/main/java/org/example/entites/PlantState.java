package org.example.entites;

public enum PlantState {
    HEALTHY,
    STRESSED,
    DORMANT,
    DISEASED
}
