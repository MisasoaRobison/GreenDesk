package org.example.controllers;

import org.example.entites.Plant;
import org.example.entites.Species;
import org.example.services.PlantServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/plants")
public class PlantController {

    @Autowired
    private PlantServices plantServices;

    // --- Créer une plante avec toutes les infos ---
    @PostMapping("/create")
    public ResponseEntity<Plant> createPlant(
            @RequestParam String name,
            @RequestParam String speciesId,
            @RequestParam(required = false) Double water,
            @RequestParam(required = false) Double temperature,
            @RequestParam(required = false) Double humidity,
            @RequestParam(required = false) Double lux
    ) {
        try {
            Plant plant;
            if (water != null && temperature != null && humidity != null && lux != null) {
                // constructeur complet
                plant = plantServices.createPlant(name, speciesId, water, temperature, humidity, lux);
            } else {
                // constructeur test / aléatoire
                plant = plantServices.createPlant(name, speciesId);
            }
            return ResponseEntity.ok(plant);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    // --- Récupérer toutes les plantes ---
    @GetMapping
    public ResponseEntity<List<Plant>> getAllPlants() {
        return ResponseEntity.ok((List<Plant>) plantServices.getAllPlants());
    }

    // --- Récupérer une plante par ID ---
    @GetMapping("/{id}")
    public ResponseEntity<Plant> getPlantById(@PathVariable String id) {
        try {
            return plantServices.getPlantById(id)
                    .map(plant -> ResponseEntity.ok(plant))
                    .orElse(ResponseEntity.notFound().build());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }



    // --- Récupérer l'état d'une plante ---
    @GetMapping("/{id}/state")
    public ResponseEntity<String> getPlantState(@PathVariable String id) {
        try {
            Optional<Plant> optPlant = plantServices.getPlantById(id);
            if (optPlant.isPresent()) {
                Plant plant = optPlant.get();
                return ResponseEntity.ok(plant.getPlantState().name());
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            // Capture toute exception provenant du service
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


}
